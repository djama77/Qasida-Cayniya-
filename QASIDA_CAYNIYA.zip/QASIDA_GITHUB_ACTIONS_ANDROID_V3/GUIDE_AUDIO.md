# Guide audio hors ligne

1. Installer Flutter et Android Studio sur Windows.
2. Décompresser le projet et ouvrir PowerShell dans son dossier.
3. Exécuter `flutter create --platforms=android --org org.example .`, puis `flutter pub get`.
4. Exécuter `flutter analyze`, corriger les éventuelles erreurs, puis `flutter run`.
5. Dans l’application, choisir Partie 1 ou Partie 2 dans le menu audio.
6. Utiliser le bouton lecture/pause. L’audio continue indépendamment de la page du PDF.
7. Générer un APK avec `flutter build apk --release`.
8. Pour F-Droid, disposer des autorisations de redistribution des fichiers audio et PDF, ou retirer ces médias du dépôt public. Le code source doit être libre et la construction vérifiable.

Aucun APK n'a été compilé ou testé ici.
