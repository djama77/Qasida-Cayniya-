# Qasida مصححة الأفراح — lecteur Flutter hors ligne

Application Android de lecture du document original (19 pages), zoom PDF, reprise de lecture, favoris et audio facultatif depuis un fichier choisi sur le téléphone. Aucun serveur, compte ou traqueur requis.

## Windows — installation et compilation
1. Installer Git, Flutter SDK et Android Studio (Android SDK + émulateur ou téléphone Android avec débogage USB).
2. Ouvrir PowerShell dans ce dossier et exécuter `flutter doctor`.
3. Exécuter `flutter create --platforms=android --org org.example .` pour générer le projet Android standard. **Avant publication**, remplacer `org.example` par un identifiant unique sous votre contrôle et conserver cet identifiant pour toutes les versions.
4. Exécuter `flutter pub get`, puis `flutter run` pour tester.
5. Exécuter `flutter build apk --release` ; APK attendu : `build/app/outputs/flutter-apk/app-release.apk`.
6. Tester sur un appareil réel : pages 1 à 19, zoom, reprise, favoris, sélection d'un audio MP3 local, lecture/pause et mode avion.

## Audio
Aucun audio n'est fourni. Le bouton « Choisir un audio » sélectionne un fichier audio local sur le téléphone. Il n'y a pas de synchronisation audio-page ni de récitation générée. Un fichier audio ne doit être redistribué qu'avec autorisation.

## Publication et droits
**IMPORTANT :** le PDF est inclus pour un prototype privé. Ses droits d'auteur et de redistribution n'ont pas été établis. Ne publiez PAS le dépôt public avec `assets/qasida.pdf` avant d'avoir vérifié les droits sur l'édition, la mise en page et toute reproduction. Le code seul peut être diffusé sous MIT (voir LICENSE), mais cette licence ne s'applique pas automatiquement au PDF.

Pour F-Droid : (1) vérifier les droits des actifs, (2) rendre le code et les actifs autorisés publics sur GitHub/GitLab, (3) vérifier les licences des plugins et dépendances transitives, (4) ajouter métadonnées Fastlane et captures réelles, (5) créer un tag `v1.0.0`, (6) proposer l'inclusion via fdroiddata/Requests for Packaging. Le dépôt doit être reproductible à partir des sources ; conserver `pubspec.lock` après `flutter pub get` et le code Android généré.

Sources : https://f-droid.org/docs/Inclusion_Policy/ ; https://fdroid.gitlab.io/jekyll-fdroid/docs/Submitting_to_F-Droid_Quick_Start_Guide/

## État
Code source de prototype fourni. APK non compilé ici : Flutter SDK/Android SDK non disponibles dans l'environnement de génération. Admission F-Droid non garantie.


## Version 1.1 — audio intégré

Deux fichiers MP3 sont inclus dans `assets/audio/` et lisibles sans Internet via le menu « Écouter une partie ». La lecture audio ne suit pas automatiquement les pages du PDF. Le bouton « Choisir un audio » permet toujours de lire un fichier local.

**Droits :** avant toute publication publique, vérifier séparément les autorisations de redistribution du PDF, de la récitation et de l'enregistrement sonore. Pour une distribution publique sans autorisation, retirer les médias concernés des assets et de `pubspec.yaml`.

**Limites :** ce ZIP contient le code source et les médias, pas un APK compilé. Exécuter `flutter create --platforms=android --org org.example .`, `flutter pub get`, `flutter analyze`, `flutter run` puis `flutter build apk --release` sur un poste configuré. Vérifier aussi la compatibilité des dépendances et les règles F-Droid avant soumission.
