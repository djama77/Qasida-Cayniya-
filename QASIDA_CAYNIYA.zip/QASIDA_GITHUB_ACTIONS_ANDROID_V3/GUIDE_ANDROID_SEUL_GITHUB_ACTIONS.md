# Guide débutant : fabriquer l’APK depuis un téléphone Android

## Avant de commencer
- Téléphone Android, connexion Internet/Wi-Fi et espace libre (archive ~60 Mo).
- Compte GitHub gratuit.
- Installer **Termux depuis F-Droid** (éviter les versions obsolètes).
- Le projet contient un PDF et deux MP3 : **ne rendez pas le dépôt public sans droits de redistribution explicites**. Un dépôt privé convient pour les tests, sous réserve des limites GitHub Actions.

## Étape 1 — Téléchargement
Téléchargez `QASIDA_GITHUB_ACTIONS_ANDROID_V3.zip` dans le dossier Téléchargements de votre téléphone.

## Étape 2 — Créer un dépôt GitHub privé
Ouvrez github.com dans votre navigateur, connectez-vous, puis **+ > New repository**. Nom : `qasida-android`. Visibilité : **Private**. Ne cochez pas README ni .gitignore (ils sont déjà fournis). Cliquez sur **Create repository**.

## Étape 3 — Préparer Termux
Ouvrez Termux et exécutez une commande à la fois :

```sh
pkg update && pkg upgrade -y
pkg install git unzip -y
termux-setup-storage
mkdir -p ~/qasida
cd ~/qasida
unzip -o '/sdcard/Download/QASIDA_GITHUB_ACTIONS_ANDROID_V3.zip'
cd QASIDA_GITHUB_ACTIONS_ANDROID_V3
ls -la .github/workflows
```

Si votre téléphone utilise le dossier `Téléchargements` autrement, localisez le ZIP dans l'application Fichiers et adaptez le chemin.

## Étape 4 — Envoyer le code depuis Termux
Remplacez `VOTRE_PSEUDO` par votre identifiant GitHub :

```sh
git init -b main
git config user.name 'Qasida Developer'
git config user.email 'votre-email@example.com'
git add .
git commit -m 'Qasida Flutter et compilation Android'
git remote add origin https://github.com/VOTRE_PSEUDO/qasida-android.git
git push -u origin main
```

GitHub n'accepte plus le mot de passe du compte pour `git push` en HTTPS. Utilisez un **personal access token (fine-grained)** limité à ce dépôt avec `Contents: Read and write` quand Termux demande un mot de passe, ou configurez une clé SSH. Ne mettez jamais le token dans les fichiers du projet ou dans la conversation. Le transfert initial des médias (~67 Mo non compressés) peut être long.

## Étape 5 — Compiler sur GitHub
Dans le navigateur : dépôt > onglet **Actions** > workflow **Compiler APK Qasida** > **Run workflow** > **Run workflow**. Un lancement automatique se produit aussi après un push sur main. Attendez le résultat (vert = succès, rouge = échec).

## Étape 6 — Télécharger l'APK
Ouvrez l'exécution réussie dans **Actions** puis descendez à **Artifacts** > **Qasida-Android-APK-test**. GitHub télécharge un ZIP contenant `app-debug.apk`. Décompressez-le avec l'application Fichiers. Il peut être nécessaire d'activer « Site pour ordinateur » dans le navigateur.

## Étape 7 — Installer sur le téléphone
Ouvrez `app-debug.apk` depuis l'application Fichiers et autorisez ponctuellement l'installation depuis cette source si Android le demande. Testez l'affichage des 19 pages, les favoris et les deux pistes audio hors ligne. Désactivez l'autorisation après installation si souhaité.

## Dépannage
- **Erreur de connexion** : vérifier le pseudo GitHub et le token (droits Contents sur le dépôt).
- **Échec flutter analyze** : ouvrir les logs Actions, corriger le code et refaire `git push`.
- **Échec de compilation** : lire le message précis dans l'étape « Compiler APK ». Aucune compilation n'a été exécutée dans ce livrable.
- **Téléchargement absent** : vérifier que le workflow est terminé et réussi et que vous êtes connecté au compte autorisé.
- **GitHub Actions désactivé** : activer les Actions dans les paramètres du dépôt, si autorisé.

## Important : test ≠ publication
L'APK **debug** est signé avec une clé de test, destiné à une installation personnelle, **pas à F-Droid**. Pour la distribution, préparer un build release et une configuration F-Droid reproductible, ainsi que les droits de publication du PDF et des MP3.
