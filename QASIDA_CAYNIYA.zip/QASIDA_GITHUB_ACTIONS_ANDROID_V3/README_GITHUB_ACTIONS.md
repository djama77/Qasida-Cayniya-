# Qasida Flutter — GitHub Actions Android

Cette version ajoute `.github/workflows/build-apk.yml` pour compiler un **APK de test** à distance sans ordinateur.

- Source : 19 pages PDF et deux MP3 intégrés pour usage hors ligne.
- Guide Android : `GUIDE_ANDROID_SEUL_GITHUB_ACTIONS.md`.
- F-Droid : voir `GUIDE_FDROID.md`, sous réserve de droits de redistribution des médias et de conformité aux exigences de F-Droid.
- Aucune compilation réelle n'a encore été vérifiée.
