# Guide de soumission F-Droid

1. Obtenir la permission écrite de redistribuer cette édition PDF (19 pages), ou utiliser une édition sous licence compatible.
2. Installer Flutter/Android SDK et exécuter les étapes README ; corriger toute erreur de compilation.
3. Tester sur Android réel sans connexion et vérifier la lisibilité du texte arabe.
4. Choisir un applicationId unique (ne pas publier `org.example`).
5. Publier le code complet, `pubspec.lock`, dossier `android/` généré, licences des actifs et captures d'écran authentiques.
6. Contrôler les dépendances natives de pdfx, just_audio et file_picker selon la politique F-Droid.
7. Taguer la version `v1.0.0` et préparer les métadonnées Fastlane.
8. Proposer une demande d'empaquetage ou une merge request dans fdroiddata ; suivre les commentaires des mainteneurs.

F-Droid peut refuser une application pour droits incertains, dépendances non libres, problème de compilation ou manque de valeur ajoutée. Le ZIP fourni est un point de départ, pas une application approuvée.
